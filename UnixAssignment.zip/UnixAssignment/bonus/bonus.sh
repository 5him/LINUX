#!/bin/bash

# Function to calculate taxes based on given salary
calculate_tax() {
  local salary=$1
  local tax=0

  if (( salary > 150000 )); then
    tax=$(( (salary - 150000) * 40 / 100 + 78000 * 20 / 100 + 37500 * 40 / 100 ))
  elif (( salary > 50000 )); then
    tax=$(( (salary - 50000) * 40 / 100 + 37500 * 20 / 100 ))
  elif (( salary > 12500 )); then
    tax=$(( (salary - 12500) * 20 / 100 ))
  fi

  echo $tax
}

# Function to compute salary including bonuses
compute_salary() {
  local sales=$1
  local bonus=0

  if (( sales >= 650000 )); then
    bonus=30000
  elif (( sales >= 500000 )); then
    bonus=25000
  elif (( sales >= 400000 )); then
    bonus=20000
  elif (( sales >= 300000 )); then
    bonus=15000
  elif (( sales >= 200000 )); then
    bonus=10000
  fi

  local total_salary=$((2000 + bonus))
  local tax=$(calculate_tax $total_salary)
  local net_salary=$((total_salary - tax))

  echo $net_salary
}

# Function to read salespersons and compute bonuses
process_salespersons() {
  declare -A sales_data

  while true; do
    echo "Enter the name of the salesperson (or 'done' to finish):"
    read name
    if [[ $name == "done" ]]; then
      break
    fi

    echo "Enter the total sales for $name:"
    read sales

    # Check if input is numeric
    if ! [[ $sales =~ ^[0-9]+$ ]]; then
      echo "Invalid sales amount. Please enter a numeric value."
      continue
    fi

    sales_data["$name"]=$sales
  done

  # Sort salespersons by name using bubble sort
  names=("${!sales_data[@]}")

  for ((i = 0; i < ${#names[@]} - 1; i++)); do
    for ((j = 0; j < ${#names[@]} - 1 - i; j++)); do
      if [[ "${names[j]}" > "${names[j + 1]}" ]]; then
        temp="${names[j]}"
        names[j]="${names[j + 1]}"
        names[j + 1]="$temp"
      fi
    done
  done

  echo "Salespersons and their net salaries after taxes:"
  for name in "${names[@]}"; do
    sales="${sales_data["$name"]}"
    net_salary=$(compute_salary $sales)
    echo "$name: £$net_salary"
  done
}

# Main function
process_salespersons
