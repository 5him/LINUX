#!/bin/bash

# Initialize a deck of cards
initialize_deck() {
    cards=("2" "3" "4" "5" "6" "7" "8" "9" "10" "J" "Q" "K" "A")
    suits=("Clubs" "Diamonds" "Hearts" "Spades")
    deck=()
    for suit in "${suits[@]}"; do
        for card in "${cards[@]}"; do
            deck+=("$card of $suit")
        done
    done
}

# Draw a card from the deck
draw_card() {
    local index=$(( RANDOM % ${#deck[@]} ))
    local card="${deck[index]}"
    deck=("${deck[@]:0:$index}" "${deck[@]:((index + 1))}")
    echo "$card"
}

# Calculate the total value of the hand
calculate_total() {
    local hand=($@) # Convert input string to array
    local total=0
    local aces=0

    for card in "${hand[@]}"; do
        local value="${card%% *}"
        case "$value" in
            "J"|"Q"|"K") value=10;;
            "A") value=11; aces=$((aces+1));;
            *) value=$value;;
        esac
        total=$((total + value))
    done

    # Adjust for aces
    while [ $total -gt 21 ] && [ $aces -gt 0 ]; do
        total=$((total - 10))
        aces=$((aces - 1))
    done

    echo $total
}

# Display hand and score
display_hand() {
    local name=$1
    local hand=("${@:2}") # Capture all arguments after the first as an array
    echo "$name's Hand: ${hand[*]} (Total: $(calculate_total "${hand[@]}"))"
}

# Main Blackjack Game
play_blackjack() {
    local dealer_hand=()
    local player_hand=()

    initialize_deck

    # Initial hands
    dealer_hand+=("$(draw_card)")
    dealer_hand+=("$(draw_card)")
    player_hand+=("$(draw_card)")
    player_hand+=("$(draw_card)")

    echo "Dealer shows: ${dealer_hand[0]}"
    display_hand "Your" "${player_hand[@]}"

    # Player's turn
    local player_total
    while true; do
        read -p "Do you want to hit or stand? (hit/stand): " choice
        if [[ $choice == "hit" ]]; then
            player_hand+=("$(draw_card)")
            display_hand "Your" "${player_hand[@]}"
            player_total=$(calculate_total "${player_hand[@]}")
            if (( player_total > 21 )); then
                echo "You bust!"
                return
            fi
        elif [[ $choice == "stand" ]]; then
            break
        else
            echo "Invalid choice. Type 'hit' or 'stand'."
        fi
    done

    # Dealer's turn
    while [ $(calculate_total "${dealer_hand[@]}") -lt 17 ]; do
        dealer_hand+=("$(draw_card)")
    done
    display_hand "Dealer's" "${dealer_hand[@]}"

    local dealer_total=$(calculate_total "${dealer_hand[@]}")
    player_total=$(calculate_total "${player_hand[@]}")

    # Determine the winner
    if (( dealer_total > 21 )) || (( player_total > dealer_total )); then
        echo "You win!"
    elif (( player_total == dealer_total )); then
        echo "It's a push."
    else
        echo "Dealer wins."
    fi
}

# Start the game
play_blackjack
