#!/bin/bash

# Function to check if input is a valid number
is_valid_number() {
  [[ $1 =~ ^[0-9]+(\.[0-9]+)?$ ]]
}

# Function to calculate the area and display results
calculate_area() {
  while true; do
    # Prompt the user for width and height
    echo "Enter the width of the rectangle (in cm):"
    read width

    echo "Enter the height of the rectangle (in cm):"
    read height

    # Check if inputs are valid numbers
    if ! is_valid_number "$width" || ! is_valid_number "$height"; then
      echo "Invalid input. Please enter numeric values."
      continue
    fi

    # Convert width and height to integers
    width_int=$(printf "%.0f" "$width")
    height_int=$(printf "%.0f" "$height")

    # Calculate the area in square centimeters
    area_cm=$((width_int * height_int))

    # Convert the area to square inches
    area_inch=$(awk "BEGIN { printf \"%.4f\", $area_cm / 2.54 / 2.54 }")

    echo "Area in square centimeters: $area_cm cm^2"
    echo "Area in square inches: $area_inch in^2"

    # Prompt for re-running or quitting
    echo "Do you want to calculate again? (y/n)"
    read choice
    if [[ $choice != "y" ]]; then
      break
    fi
  done
}

# Call the main function
calculate_area
